from django.contrib import admin
from  .models import Rezepte

admin.site.register(Rezepte) #mit diesem Befehl kann man die Datenbank auf der Adminseite bearbeiten
# Register your models here.