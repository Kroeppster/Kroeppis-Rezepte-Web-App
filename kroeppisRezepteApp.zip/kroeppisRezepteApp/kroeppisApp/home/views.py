from django.shortcuts import render
from django.http import HttpResponse
from datenbank.models import Rezepte


def home_view(request, *args, **kwargs):  # Diese Funktion generiert die Homepage.
    return render(request, "home.html", {})


def search_view(request, *args, **kwargs):  # Diese Funktion generiert die Suchseite für die Suche nach Namen.
    if request.method == "POST":
        searched = request.POST['searched']
        rezepte = Rezepte.objects.filter(name__contains=searched)
        return render(request, "search.html", {'searched': searched, 'rezepte': rezepte})

    else:
        return render(request, "search.html", {})


def rezeptsuche_view(request, *args, **kwargs):  # Diese Funktion generiert die Suchseite.
    if request.method == "POST":
        searched = request.POST['searched']
        rezepte = Rezepte.objects.filter(zutaten__contains=searched)
        return render(request, "rezeptsuche.html", {'searched': searched, 'rezepte': rezepte})

    else:
        return render(request, "rezeptsuche.html", {})



def rezeptliste_view(request, *args, **kwargs):  # Diese Funktion generiert die Liste aller Rezepte.
    rezepte_liste = Rezepte.objects.order_by('name')

    return render(request, "rezepteListe.html", {'rezepte_liste' : rezepte_liste})


def rezepte_einzeln(request, rezepte_id): # Diese Funktion generiert die Anzeige von einzelnen Rezepten.
    Rezept = Rezepte.objects.get(pk=rezepte_id)
    return render(request, "rezepte.html", {'Rezept': Rezept})

